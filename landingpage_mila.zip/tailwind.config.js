/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./project.html"],
  theme: {
    extend: {},
  },
  plugins: [],
}

